from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route("/tempodeviagem", methods=['POST'])
def calculartempo():
    distancia = float(request.form['distancia'])
    velocidade = float(request.form['velocidade'])
    resultado = round((distancia/velocidade),2)
    return render_template('index.html', resultado = resultado)

if __name__ == '__main__':
    app.run(debug=True)


