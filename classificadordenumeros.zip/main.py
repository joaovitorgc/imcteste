from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route("/classificarnumeros", methods=['POST'])
def classificarnumero():
    numeros = ''
    numero = int(request.form['numero'])

    if numero%2 == 0 and numero > 0:
        numeros = "par e positivo"

    elif numero%2 == 0 and numero < 0:
        numeros = "par e negativo"

    elif numero%2 != 0 and numero > 0:
        numeros = "impar e positivo"

    elif numero % 2 != 0 and numero < 0:
        numeros = "impar e negativo"

    print(numeros)
    return render_template('index.html', numeros=numeros)

if __name__ == '__main__':
    app.run(debug=True)


