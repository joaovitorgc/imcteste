from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")
@app.route("/conversormoeda", methods=['POST'])
def conversormoeda():
    real = float(request.form['real'])
    dolar = 5.67
    resultado =  round((real/dolar),2)
    return render_template('index.html', resultado = resultado)

if __name__ == '__main__':
    app.run(debug=True)