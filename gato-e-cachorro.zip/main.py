from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route("/calculoidd", methods=['POST'])
def iddpet():
    idade = int(request.form['idade'])
    pet = str(request.form['pet'])
    iddhumana = ""

    if idade == 1:
        iddhumana = 15
    elif idade == 2:
        iddhumana = 24
    elif idade >= 3:
        iddhumana = 24+(idade-2)*5

    return render_template('index.html', iddhumana=iddhumana)

if __name__ == '__main__':
    app.run(debug=True)