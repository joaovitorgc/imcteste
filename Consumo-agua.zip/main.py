from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route("/calculoagua", methods=['POST'])
def aguaideal():
    peso = float(request.form['peso'])
    quantidadeideal = peso*35/1000

    return render_template('index.html', quantidadeideal=quantidadeideal)

if __name__ == '__main__':
    app.run(debug=True)


