from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route("/conversortemperatura", methods=['POST'])
def convertertemp():
    celsius = float(request.form['celsius'])
    kelvin = round((celsius+273),2)
    farenheit = round(((celsius * 9/5) + 32),2)

    resultado = f' {farenheit} farenheit - {kelvin} kelvin '
    return render_template('index.html',resultado=resultado)

if __name__ == '__main__':
    app.run(debug=True)

